package project;

public class constructortype {
    
    public constructortype() 
    {
        System.out.println("This is a default constructor.");
    }
    
    public constructortype(int value) {
        System.out.println("This is a parameterized constructor with value: " + value);
    }
    
    public static void main(String[] args) 
    {
        constructortype object1 = new constructortype(); 
        constructortype object2 = new constructortype(10); 
    }
}
