package project;

class Node
{
	int data;
	Node next;
	
	Node(int data)
	{
		this.data = data;
		this.next = null;
	}
}
class LinkedList
{
	Node head;
	
	void insert(int data)
	{
		Node newNode = new Node(data);
		if(head == null)
		{
			head = newNode;
		}
		else
		{
			Node temp = head;
			while(temp.next != null)
			{
				temp = temp.next;
			}
			temp.next = newNode;
		}
		
	}
	
	void deletekey(int key)
	{
		Node temp = head;
		Node prev = null;
		
		if(temp != null && temp.data == key)
		{
			head = temp.next;
			return;
		}
		
		while(temp != null && temp.data != key)
		{
			prev = temp;
			temp = temp.next;
		}
		
		if(temp == null)
		{
			System.out.println("Key not found");
			return;
		}
		prev.next = temp.next;
	}
	
	void display()
	{
		Node temp = head;
		while(temp != null)
		{
			System.out.println(temp.data+"");
			temp = temp.next;
		}
		System.err.println();
	}
}
public class singlylinkedlist 
{
	public static void main(String[] args) 
	{
		LinkedList list = new LinkedList();
		
		list.insert(1);
		list.insert(2);
		list.insert(3);
		list.insert(4);
		list.insert(5);
		
		System.out.println("Original Linked List");
		
		list.deletekey(3);
		
		System.out.println("Linked List after deleting the first occurrence of key 3:");
        list.display();	
	}
}
