package project;

public class localinnerclass 
{
    private int outerData = 10;
    void display() 
    {
        int localVar = 20;
        class LocalInner 
        {
            void show()
{
                System.out.println("Outer Data: " + outerData);
                System.out.println("Local Variable: " + localVar);
            }
        }
        LocalInner localInner = new LocalInner();
        localInner.show();
    }
    public static void main(String[] args) 
    {
        localinnerclass outerObj = new localinnerclass();
        outerObj.display();
    }
}
