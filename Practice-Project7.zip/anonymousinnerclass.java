package project;

public class anonymousinnerclass 
{
    public static void main(String[] args) 
    {
        AbstractClass abstractObj = new AbstractClass() 
        {
            @Override
            public void abstractMethod() 
            {
                System.out.println("Abstract method implemented by anonymous inner class");
            }
        };
        abstractObj.abstractMethod();
    }
}

abstract class AbstractClass 
{
    public abstract void abstractMethod();
}
