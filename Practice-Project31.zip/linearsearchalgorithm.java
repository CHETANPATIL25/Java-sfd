package project;

public class linearsearchalgorithm 
{
	public static void main(String[] args) 
	{
		int[] arr = {5, 7, 2, 9, 1, 4, 6, 8, 3};
		int target = 1;
		boolean found = linearSearch(arr,target);
		
		if(found)
		{
			System.out.println("Element Found in array is "+target);
		}
		else
		{
			System.out.println("Element is Not Found");
		}
	}

	private static boolean linearSearch(int[] arr, int target) 
	{
		for(int i = 0;i<arr.length;i++)
		{
			if(arr[i] == target)
			{
				return true;
			}
		}
		return false;
	}

}
