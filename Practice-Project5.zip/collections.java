package project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class collections 
{
	public static void main(String args[])
	{
		System.out.println("ArrayList");
		List<Integer> arrayList = new ArrayList<>();
		arrayList.add(10);
		arrayList.add(20);
		arrayList.add(30);
		System.out.println("Content of ArrayList: "+arrayList);
		
		System.out.println("\nLinkedList");
		List<Double> linkedList = new LinkedList<>();
		linkedList.add(3.18);
		linkedList.add(5.22);
		linkedList.add(8.66);
		System.out.println("Content of LinkedList: "+linkedList);
		
		System.out.println("\nHashset");
		Set<String> hashSet = new HashSet<>();
		hashSet.add("Chetan");
		hashSet.add("Cristiano");
		hashSet.add("Football");
		System.out.println("Content of HashSet: "+hashSet);
		
		System.out.println("\nVector");
		List<Integer> vector = new Vector<>();
		vector.add(20);
		vector.add(39);
		vector.add(80);
		System.out.println("Content of Vector: "+vector);
		
		System.out.println("\nLinkedHashSet");
		Set<String> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add("Apple");
        linkedHashSet.add("Banana");
        linkedHashSet.add("Orange");
        System.out.println("Contents of LinkedHashSet: " + linkedHashSet);
        
        System.out.println("\nHashMap");
        Map<String, String> hashMap = new HashMap<>();
        hashMap.put("USA", "Washington D.C.");
        hashMap.put("France", "Paris");
        hashMap.put("Japan", "Tokyo");
        System.out.println("Contents of HashMap: " + hashMap);
	}
}
