package project;

public class array 
{
	public static void main(String[] args) 
	{
        int[] numbers = {1, 2, 3, 4, 5};
        System.out.println("One-dimensional array of integers:");
        for (int i = 0; i < numbers.length; i++) 
        {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }

        int[][] matrix = {
                {1, 2, 3},
                {4, 5},
                {6, 7, 8, 9}
        };

        System.out.println("Length of each row in the 2D array:");
        for (int i = 0; i < matrix.length; i++) 
        {
            System.out.println("Row " + i + " length: " + matrix[i].length);
        }
 
    }
}

