package project;

class DoublyNode
{
	int data;
	DoublyNode prev;
	DoublyNode next;
	
	DoublyNode(int data)
	{
		this.data = data;
		this.next = null;
		this.prev = null;
	}
}
public class doublylinkedlist 
{
	DoublyNode head;
	
	void insert(int data)
	{
		DoublyNode newNode = new DoublyNode(data);
		
		if(head == null)
		{
			head = newNode;
		}
		else
		{
			DoublyNode temp = head;
			while(temp.next != null)
			{
				temp = temp.next;
			}
			temp.next = newNode;
			newNode.prev = temp;
		}
	}
	void traverseForward() 
	{
		System.out.println("Forward Traversal:");
	    DoublyNode temp = head;
	    while (temp != null) 
	    {
	    	System.out.print(temp.data + " ");
	        temp = temp.next;
	    }
	    System.out.println();
	}
	void traverseBackward() 
	{
		System.out.println("Backward traversal:");
		DoublyNode temp = head;
	    while (temp.next != null) 
	    {
	    	temp = temp.next;
	    }
	    while (temp != null) 
	    {
	    	System.out.print(temp.data + " ");
	        temp = temp.prev;
	    }
	    System.out.println();
	}
	public static void main(String[] args) 
	{
		doublylinkedlist dll = new doublylinkedlist();
		
		dll.insert(1);
        dll.insert(2);
        dll.insert(3);
        dll.insert(4);
        dll.insert(5);

        dll.traverseForward();

        dll.traverseBackward();
    }
}