package project;

class mythread extends Thread
{
	public void run()
	{
		System.out.println("Thread is Running....");
	}
	
	public static void main(String args[])
	{
		mythread mt = new mythread();
		mt.start();
	}
}
