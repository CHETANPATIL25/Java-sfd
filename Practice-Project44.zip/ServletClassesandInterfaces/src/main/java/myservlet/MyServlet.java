package myservlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;

@WebServlet("/MyServlet")
public class MyServlet extends GenericServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // Retrieve data from the request
        String data = request.getParameter("data");

        // Set content type of the response
        response.setContentType("text/html");

        // Write response
        response.getWriter().println("<!DOCTYPE html>");
        response.getWriter().println("<html>");
        response.getWriter().println("<head>");
        response.getWriter().println("<title>Data Submitted to Servlet</title>");
        response.getWriter().println("</head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h2>Data Submitted to Servlet:</h2>");
        response.getWriter().println("<p>" + data + "</p>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }

    // Other methods of Servlet interface are not used in this example
}

