package project;

class Vehicle
{
	public void start()
	{
		System.out.println("Vehicle Started");
	}
}
class Car extends Vehicle
{
	public void drive()
	{
		System.out.println("Car is being driven");
	}
}
public class inheritanceexample 
{
	public static void main(String[] args) 
	{
		Car mycar = new Car();
		mycar.start();
		mycar.drive();
	}

}
