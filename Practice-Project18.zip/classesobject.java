package project;

class Student
{
	private String name;
	private int age;
	
	public Student(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	
	public void displayInfo()
	{
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
	}
}
public class classesobject 
{
	public static void main(String[] args)
	{
		Student student = new Student("Cristiano",39);
		student.displayInfo();
	}
}
