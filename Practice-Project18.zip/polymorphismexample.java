package project;

class Animal
{
	public void makesound()
	{
		System.out.println("Animal makes sound");
	}
}
class Dog extends Animal
{
	@Override
	public void makesound()
	{
		System.out.println("Dog Barks");
	}
}
class Cat extends Animal
{
	@Override
	public void makesound()
	{
		System.out.println("Cat meows");
	}
}
public class polymorphismexample 
{
	public static void main(String[] args) 
	{
		Animal animal1 = new Dog();
		Animal animal2 = new Cat();
		
		animal1.makesound();
		animal2.makesound();
	}

}
