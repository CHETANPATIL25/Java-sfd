package project;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class map 
{
	public static void main(String args[])
	{
		System.out.println("Hashmap");
		Map<String, Integer> hashMap = new HashMap<>();
		hashMap.put("Chetan",25);
		hashMap.put("Cristiano",39);
		hashMap.put("Ozil",54);
        System.out.println("Contents of HashMap: " + hashMap);
        
        System.out.println("\nTreeMap");
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Apple", 50);
        treeMap.put("Banana", 40);
        treeMap.put("Orange", 60);
        System.out.println("Contents of TreeMap: " + treeMap);
        
        System.out.println("\nLinkedHashMap");
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Pen", 5);
        linkedHashMap.put("Bat", 20);
        linkedHashMap.put("Eagle", 85);
        System.out.println("Contents of LinkedHashMap: " + linkedHashMap);
        
        System.out.println("\nHashtable");
        Hashtable<String, Integer> hashtable = new Hashtable<>();
        hashtable.put("One", 100);
        hashtable.put("Two", 200);
        hashtable.put("Three", 300);
        System.out.println("Contents of Hashtable: " + hashtable);
	}
}
