package project;

import java.util.Arrays;

public class arrayrotation {

	public static void main(String[] args) 
	{
		int[] array = {1,2,3,4,5,6,7,8,9,10};
		System.out.println("Original Array:"+Arrays.toString(array));
		
		rightRotateByFive(array);
		
		System.out.println("Array after Rotating by 5 steps:"+Arrays.toString(array));
	}

	private static void rightRotateByFive(int[] arr) 
	{
		int n = arr.length;
		int[] rotatedArray = new int[n];
		
		for(int i = 0;i<n;i++)
		{
			int newIndex = (i+5)%n;
			rotatedArray[newIndex] = arr[i];
		}
		System.arraycopy(rotatedArray, 0, arr, 0, n);
	}

}
