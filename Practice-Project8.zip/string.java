package project;

public class string 
{
	public static void main(String args[])
	{
		System.out.println("String methods");
		
		String str = "Hello, World!";
	    System.out.println("Original String: " + str);

	    System.out.println("Length of string: " + str.length());
	    System.out.println("Substring from index 7: " + str.substring(7));
		
	    String s3 = new String("Cristiano");
		String s4 = new String("Ronaldo");
		System.out.println("Comparison of string:"+s3.compareTo(s4));
		
		String emptyStr = "";
		System.out.println("Is Empty:" +emptyStr.isEmpty());
		
		System.out.println("LowerCase: "+str.toLowerCase());
		
		String replaceStr = str.replace('e', 'a');
		System.out.println("Replaced String:"+replaceStr);
		
		String x = " Welcome to Java";
		String y = " Welcome to JAVA";
		System.out.println("Equals String: "+x.equals(y));
		
		System.out.println("\nCreating StringBuffer:");
	    
		StringBuffer stringBuffer = new StringBuffer("Welcome");
	    stringBuffer.append(" to Java!");
	    System.out.println(stringBuffer);	
	    
	    stringBuffer.insert(8,"back ");
		System.out.println(stringBuffer);
		
		StringBuffer replacedBuffer = new StringBuffer("Hello");
	    replacedBuffer.replace(0, 2, "hEl");
	    System.out.println(replacedBuffer);
 
	    StringBuffer deletedBuffer = new StringBuffer("Hello");
	    deletedBuffer.delete(1, 3);
	    System.out.println(deletedBuffer);
	    
        System.out.println("\nCreating StringBuilder:");
        StringBuilder stringBuilder = new StringBuilder("Happy");
        stringBuilder.append(" Learning");
        System.out.println(stringBuilder);
        
        System.out.println(stringBuilder.delete(0,1));
        
        System.out.println(stringBuilder.insert(1,"Welcome"));
        
        System.out.println(stringBuilder.reverse());
        
        System.out.println("\nConversion of Strings to StringBuffer and StringBuilder:");
        
        StringBuffer convertedBuffer = new StringBuffer(str);
        convertedBuffer.reverse();
        System.out.println("String to StringBuffer:" +convertedBuffer);
        
        StringBuilder convertedBuilder = new StringBuilder(str);
        convertedBuilder.append(" Have a nice day!");
        System.out.println("String to StringBuilder: " + convertedBuilder);
		
	}
}
