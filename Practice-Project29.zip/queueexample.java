package project;

import java.util.LinkedList;
import java.util.Queue;

public class queueexample 
{
    public static void main(String[] args) 
    {
        Queue<String> playersName = new LinkedList<>();
        playersName.add("Ronaldo");
        playersName.add("M.Ozil");
        playersName.add("Neymar");
        playersName.add("Vini Jr");
        playersName.add("Mbappe");

        System.out.println("Football of Players Name: " + playersName);

        System.out.println("Front of the Queue: " + playersName.peek());

        playersName.remove();

        System.out.println("After removing Front of the Queue: " + playersName);

        System.out.println("Size of the Queue: " + playersName.size());
    }
}
