package project;

import java.io.FileWriter;
import java.io.IOException;

public class updatefile 
{
	public static void main(String[] args) 
	{
		try
		{
			FileWriter writer = new FileWriter("Example.txt",true);
			writer.write("\nHello How are you?");
			writer.close();
			System.out.println("File Updated Successfully");
		}
		catch (IOException e)
		{
			System.out.println("An error occurred"+e.getMessage());
		}
	}

}
