package project;

import java.io.File;

public class deletefile 
{
	public static void main(String[] args) 
	{
		File file = new File("Example.txt");
		if(file.delete())
		{
			System.out.println("File deleted successfully");
		}
		else
		{
			System.out.println("Failed to delete the file");
		}
	}

}
