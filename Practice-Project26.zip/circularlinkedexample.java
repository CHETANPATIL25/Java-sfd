package project;

class Nodee
{
	int data;
	Nodee next;
	
	Nodee(int data)
	{
		this.data = data;
		this.next = null;
	}
}

class Circular
{
	Nodee head;
	
	void insertSorted(int data)
	{
		Nodee newNode = new Nodee(data);
		
		if(head == null)
		{
			head = newNode;
			head.next = head;
			return;
		}
			
		if(data < head.data)
		{
			newNode.next = head;
			Nodee temp = head;
			while(temp.next != head)
			{
				temp = temp.next;
			}
			temp.next = newNode;
			head = newNode;
			return;
		}
		
		Nodee prev = null, current = head;
		do 
		{
	        if (current.data > data) 
	        {
	            break;
	        }
	        prev = current;
	        current = current.next;
	    } 
		while (current != head);
		
		prev.next = newNode;
		newNode.next = current;
	}
	
	void display()
	{
		if(head == null)	
		{	
			System.out.println("List is Empty.");
			return;
		}
		Nodee temp = head;
		do
		{
			System.out.println(temp.data+"");
			temp = temp.next;
		}
		while(temp != head);
	}
}
public class circularlinkedexample 
{
	public static void main(String[] args) 
	{
		Circular list = new Circular();
		
		list.insertSorted(5);
		list.insertSorted(10);
		list.insertSorted(7);
		list.insertSorted(3);
		list.insertSorted(8);
		
		System.out.println("Sorted Circular Linked List:");
	    list.display();	
	}

}
