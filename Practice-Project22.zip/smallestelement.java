package project;

import java.util.Arrays;

public class smallestelement 
{
	public static void main(String[] args)
	{
		int[] list = {9,5,2,7,1,8,11,12};
		
		int fourthSmallest = findFourthSmallest(list);
		
		System.out.println("Fourth Smallest Element:"+ fourthSmallest);
	}

	private static int findFourthSmallest(int[] arr) 
	{
		if(arr.length < 4)
		{
			System.out.println("List has less than 4 elements");
		}
		
		Arrays.sort(arr);
		
		return arr[3];
	}

}
