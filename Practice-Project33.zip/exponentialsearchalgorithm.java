package project;

import java.util.Arrays;

public class exponentialsearchalgorithm 
{
	public static void main(String[] args) 
	{

		int[] arr = {1,2,3,4,5,6,7,8,9};
		int target = 8;
		boolean found = exponentialSearch(arr,target);
		
		if(found)
		{
			System.out.println("Element "+target+" is Found");
		}
		else
		{
			System.out.println("Element is Not Found");
		}
	}
	private static boolean exponentialSearch(int[] arr, int target) 
	{
		int n = arr.length;
		if(arr[0] == target)
		{
			return true;
		}
		
		int i = 1;
		while(i<n && arr[i] <= target)
		{
			i *= 2;
		}
		return binarySearch(arr, target , i/2, Math.min(i,n-1));
	}
	private static boolean binarySearch(int[] arr, int target, int left, int right) 
	{
		while(left<=right)
		{
			int mid = left + (right- left)/2;
			
			if(arr[mid] == target)
			{
				return true;
			}
			
			else if(arr[mid]<target)
			{
				left = mid +1;
			}
			
			else
			{
				right = mid - 1;
			}
		}
		return false;
	}
}
