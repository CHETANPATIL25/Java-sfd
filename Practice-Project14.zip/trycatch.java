package project;

import java.util.Scanner;

public class trycatch 
{
	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		try
		{
			System.out.println("Entry an integer: ");
			int number = scanner.nextInt();
			System.out.println("You entered: "+number);
		}
		catch (Exception e)
		{
			System.out.println("An error occured: "+e.getMessage());
		}
		finally
		{
			scanner.close();
			System.out.println("Scanner closed");
		}
	}
}
