package project;

public class sleepandwait 
{
	public static void main(String[] args) 
	{
		System.out.println("Sleep..");
		for(int i = 0;i<5;i++)
		{
			System.out.println("CountDown:"+i);
			try 
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException e)
			{
				System.out.println("Sleep Interrupted");
				
			}
		}
		System.out.println("\nWait..");
		Object lock = new Object();
		synchronized (lock)
		{
			try
			{
				System.out.println("Thread waiting....");
				lock.wait(3000);
				System.out.println("Thread awake!");
			}
			catch (InterruptedException e )
			{
				System.out.println("Wait Interrupted");
			}
		}
	}

}
