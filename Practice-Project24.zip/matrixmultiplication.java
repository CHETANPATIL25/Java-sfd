package project;

import java.util.Scanner;

public class matrixmultiplication 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the elements of first matrix");
		int[][] matrix1 = new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				matrix1[i][j] = scanner.nextInt();
			}
		}
		System.out.println("Enter the elements of second matrix");
		int[][] matrix2 = new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				matrix2[i][j] = scanner.nextInt();
			}
		}
		int[][] result = multiplyMatrices(matrix1,matrix2);
		
		System.out.println("Result Matrix:");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.err.println(result[i][j]+"");
			}
		}
		scanner.close();
	}
	private static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2) 
	{
		int[][] result = new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				for(int k=0;k<2;k++)
				{
					result[i][j] += matrix1[i][k] * matrix2[k][j];
					
				}
				
			}
			
		}
		return result;
	}
}
