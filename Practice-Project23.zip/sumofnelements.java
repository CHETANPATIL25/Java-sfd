package project;

import java.util.Scanner;

public class sumofnelements 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
			
		System.out.println("Enter the number of Elements(n)");
		int n = scanner.nextInt();
		
		int[] arr = new int[n];
		
		System.out.println("Enter the array elements");
		for(int i = 0; i < n ; i++)
		{
			arr[i] = scanner.nextInt();
			
		}
        System.out.print("Enter the range (L and R) where 0 <= L <= R <= n-1: ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();
        
        if(L < 0 || R >= n || L > R)
        {
        	System.out.println("Invalid Range");
        }
        
        int sum = 0;
        for(int i = L; i <=R ; i++)
        {
        	sum += arr[i];
        }
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
        scanner.close();
	}

}
