package project;

public class methodoverloading 
{
    
    public int add(int a, int b) 
    {
        return a + b;
    }
    
    public int add(int a, int b, int c) 
    {
        return a + b + c;
    }
    
    public static void main(String[] args) 
    {
        methodoverloading obj = new methodoverloading();
        
        System.out.println("Sum of 5 and 3: " + obj.add(5, 3)); 
        System.out.println("Sum of 5, 3, and 2: " + obj.add(5, 3, 2));
        
    }
}
