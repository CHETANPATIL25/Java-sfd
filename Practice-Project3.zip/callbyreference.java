package project;

public class callbyreference {
    
    public void modifyArray(int[] arr) 
    {
        arr[0] = 100;
        System.out.println("Inside modifyArray method: arr[0] = " + arr[0]);
    }
    
    public static void main(String[] args) 
    {
        callbyreference obj = new callbyreference();
        
        int[] array = {10, 20, 30};
        System.out.println("Before calling modifyArray method: array[0] = " + array[0]);
        
        obj.modifyArray(array);
        
        System.out.println("After calling modifyArray method: array[0] = " + array[0]);
    }
}
