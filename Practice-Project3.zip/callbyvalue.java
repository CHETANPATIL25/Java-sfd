package project;

public class callbyvalue 
{
    public void modifyValue(int x) 
    {
        x = x * 2;
        System.out.println("Inside modifyValue method: x = " + x);
    }
    public static void main(String[] args) 
    {
        callbyvalue obj = new callbyvalue();   
        int num = 10;
        System.out.println("Before calling modifyValue method: num = " + num);      
        obj.modifyValue(num);     
        System.out.println("After calling modifyValue method: num = " + num);
    }
}
