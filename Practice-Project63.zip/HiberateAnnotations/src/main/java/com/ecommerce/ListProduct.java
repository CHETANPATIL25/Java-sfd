package com.ecommerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ecommerce.EProduct; // Correct import statement
import com.ecommerce.HibernateUtil;

@WebServlet("/listProducts")
public class ListProduct extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            SessionFactory factory = HibernateUtil.getSessionFactory();

            Session session = factory.openSession();
            Transaction tx = session.beginTransaction();

            List<EProduct> productList = session.createQuery("FROM EProduct").list();

            tx.commit();
            session.close();

            response.setContentType("application/json"); // Set content type to JSON
            PrintWriter out = response.getWriter();
            out.println("["); // Start of JSON array
            for (int i = 0; i < productList.size(); i++) {
                EProduct product = productList.get(i);
                out.println("{");
                out.println("\"name\": \"" + product.getName() + "\",");
                out.println("\"price\": " + product.getPrice());
                if (i < productList.size() - 1) {
                    out.println("},");
                } else {
                    out.println("}");
                }
            }
            out.println("]"); // End of JSON array
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new ServletException(ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
