
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ecommerce.util.HibernateUtil; // Import HibernateUtil from the correct package

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProductDetails() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            SessionFactory factory = HibernateUtil.getSessionFactory();
            Session session = factory.openSession();
            Transaction tx = session.beginTransaction();

            List<EProduct> list = session.createQuery("from EProduct").list();

            PrintWriter out = response.getWriter();
            out.println("<html><body>");

            out.println("<b>Product Details</b><br>");

            for (EProduct p : list) {
                out.println("ID: " + p.getID() + ", Name: " + p.getName() +
                        ", Price: " + p.getPrice() + ", Date Added: " + p.getDateAdded());

                PDescription descrip = p.getPdescrip();
                out.println("<br>Description:" + descrip.getDescrip());
                out.println("<hr>");
            }

            tx.commit();
            session.close();

            out.println("</body></html>");
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
