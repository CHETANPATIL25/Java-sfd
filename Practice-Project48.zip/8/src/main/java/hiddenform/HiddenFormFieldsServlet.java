package hiddenform;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/HiddenFormFieldsServlet")
public class HiddenFormFieldsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Get or create session
        HttpSession session = request.getSession();
        
        // Increment visit count
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }
        session.setAttribute("visitCount", visitCount);
        
        // Display visit count and form
        out.println("<html><head><title>Session Tracking with Hidden Form Fields</title></head><body>");
        out.println("<h2>Session Tracking with Hidden Form Fields</h2>");
        out.println("<p>Number of visits: " + visitCount + "</p>");
        out.println("<form action='HiddenFormFieldsServlet' method='post'>");
        out.println("<input type='hidden' name='action' value='logout'>");
        out.println("<input type='submit' value='Logout'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Invalidate the session
        }
        response.sendRedirect("HiddenFormFieldsServlet"); // Redirect to doGet
    }
}
