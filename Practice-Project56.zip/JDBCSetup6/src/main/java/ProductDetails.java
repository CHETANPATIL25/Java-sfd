import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.DBConnection;

@WebServlet("/ProductDetails")
public class ProductDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProductDetails() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            PrintWriter out = response.getWriter();
            out.println("<html><body>");

            // Load database connection properties from config file
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/config.properties");
            Properties props = new Properties();
            props.load(in);

            // Establish database connection
            DBConnection conn = new DBConnection(props.getProperty("url"), props.getProperty("userid"), props.getProperty("password"));
            Statement stmt = conn.getConnection().createStatement();

            // Check if the table exists, if not, create it
            boolean tableExists = checkIfTableExists(stmt, "eproduct1");
            if (!tableExists) {
                createProductTable(stmt);
                out.println("Product table created successfully<br>");
            }

            // Insert operation
            int insertedRows = stmt.executeUpdate("INSERT INTO eproduct1 (name, price, date_added) VALUES ('New Product', 17800.00, NOW())");
            out.println("Executed an insert operation. Rows affected: " + insertedRows + "<br>");

            // Update operation
            int updatedRows = stmt.executeUpdate("UPDATE eproduct1 SET price=2000 WHERE name = 'New Product'");
            out.println("Executed an update operation. Rows affected: " + updatedRows + "<br>");

            // Delete operation
            int deletedRows = stmt.executeUpdate("DELETE FROM eproduct1 WHERE name = 'New Product'");
            out.println("Executed a delete operation. Rows affected: " + deletedRows + "<br>");

            stmt.close();
            conn.closeConnection();

            out.println("</body></html>");
            conn.closeConnection();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    // Helper method to check if a table exists in the database
    private boolean checkIfTableExists(Statement statement, String tableName) throws SQLException {
        ResultSet resultSet = statement.executeQuery("SHOW TABLES LIKE '" + tableName + "'");
        return resultSet.next();
    }

    // Helper method to create the product table if it doesn't exist
    private void createProductTable(Statement statement) throws SQLException {
        statement.executeUpdate("CREATE TABLE eproduct1 (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), price DECIMAL(10,2), date_added TIMESTAMP)");
    }
}
