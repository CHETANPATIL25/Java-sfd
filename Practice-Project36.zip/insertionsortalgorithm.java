package project;

import java.util.Arrays;

public class insertionsortalgorithm 
{
	public static void main(String[] args) 
	{
		int[] array = {89,24,56,45,11};
		
		System.out.println("Original Array: "+Arrays.toString(array));
		
		insertionSort(array);
		
		System.out.println("Sorted Array: "+Arrays.toString(array));
	}

	private static void insertionSort(int[] arr) 
	{
		int n = arr.length;
		for(int i=1;i<n;i++)
		{
			int key = arr[i];
			int j = i-1;
			
			while(j>=0 && arr[j]>key)
			{
				arr[j+1] = arr[j];
				j = j-1;
			}
			arr[j+1] = key;
		}
	}
}
