package project;

class MessageSender
{
	public void sendmessage(String message)
	{
		System.out.println("Sender Message:" +message);
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException e)
		{
			System.out.println("Thread Interrupted");
		}
		System.out.println(message + " Sent Succesfully");
	}
	
}
class ThreadMessageSender extends Thread
{
	private String message;
	private Thread thread;
	private MessageSender messageSender;
	
	ThreadMessageSender(String msg , MessageSender sender)
	{
		message = msg;
		messageSender = sender;
	}
	
	public void run()
	{
		synchronized(messageSender)
		{
			messageSender.sendmessage(message);
		}
	}
		
}

public class synchronization 
{
	public static void main(String args[])
	{
		MessageSender messageSender = new MessageSender();
		ThreadMessageSender sender1 = new ThreadMessageSender("Hello",messageSender);
		ThreadMessageSender sender2 = new ThreadMessageSender("Goodbye",messageSender);
		sender1.start();
		sender2.start();
		try
		{
			sender1.join();
			sender2.join();
		}
		catch(InterruptedException e)
		{
			System.out.println("Interrupted");
		}
		
	}
}
