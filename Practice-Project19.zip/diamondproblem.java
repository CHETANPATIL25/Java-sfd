package project;

interface FirstInterface 
{
    default void display() 
    {
        System.out.println("Default method from FirstInterface");
    }
}

interface SecondInterface 
{
    default void display() 
    {
        System.out.println("Default method from SecondInterface");
    }
}

public class diamondproblem implements FirstInterface, SecondInterface 
{
    public void display() 
    {
        FirstInterface.super.display();
        SecondInterface.super.display();
    }

    public static void main(String args[]) 
    {
        diamondproblem obj = new diamondproblem();
        obj.display();
    }
}
